#include "game.h"
#include "graphics.h"
#include "config.h"

void Game::spawnMeteorite()
{
	if (!meteorite)
	{
		meteorite = new Meteorite(*this);
	}
}

void Game::spawnLaserBeam()
{
	if (!laserbeam)
	{
		laserbeam = new Laser(*this);
		
	}
}

void Game::checkLaserBeam()
{
	if (laserbeam && !laserbeam->isLaserActive())
	{
		delete laserbeam;
		laserbeam = nullptr;
	}
}

void Game::checkMeteorite()
{
	if (meteorite && !meteorite->isActive())
	{
		delete meteorite;
		meteorite = nullptr;
	}
}

bool Game::checkCollision()
{
	if (!spaceship || !meteorite)
	{
		return false;
	}
	Disk d1 = spaceship->getCollisionHull();
	Disk d2 = meteorite->getCollisionHull();
	Disk l1 = laserbeam->getCollisionHull();

	float dx = d1.cx - d2.cx;
	float dy = d1.cy - d2.cy;
	float lx = l1.cx - d2.cx;
	float ly = l1.cy - d2.cy;

	if (sqrt(lx * lx + ly * ly) < l1.radius + d2.radius)
	{
		delete laserbeam;
		laserbeam = nullptr;
		delete meteorite;
		meteorite = nullptr; 
	} 
	else if (sqrt(dx * dx + dy * dy) < d1.radius + d2.radius)
	{
		spaceship->drainLife(0.2f);
		if (spaceship->getRemainingLife() == 0.0f)
		{
			delete spaceship;
			spaceship = nullptr;

		}
		return true;
	}
	else {
		return false;
	}
}

void Game::update()
{
	if (!new_spaceship && graphics::getGlobalTime() > 00)
	{
		spaceship = new Spaceship(*this);
		laserbeam = new Laser(*this);
		new_spaceship = true;
	}

	
	if (spaceship)
		spaceship->update();

	checkMeteorite();
	spawnMeteorite();

	if (meteorite)
		meteorite->update();

	if (laserbeam)
		laserbeam->update();

	checkLaserBeam();
	spawnLaserBeam();

	//edw xrisimopoiw to Collision
	if (checkCollision())
	{
		//estw oti katastrefetai o meteoritis meta ti sigrousi(diagrafetai)
		delete meteorite;
		meteorite = nullptr;
		
	}
}

void Game::draw()
{
	graphics::Brush br;
	br.texture = std::string(ASSET_PATH) + "moon.png";
	br.outline_opacity = 0.0f;

	//draw background
	graphics::drawRect(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2, CANVAS_WIDTH, CANVAS_HEIGHT, br);

	//draw spaceship
	if (spaceship)
		spaceship->draw();

	//draw laserbeam
	if (laserbeam)
		laserbeam->draw();

	//draw meteorite
	if (meteorite)
	    meteorite->draw();

	if (spaceship && debug_mode) {
		char info[40];
		sprintf_s(info, "(%6.2f, %6.2f)", spaceship->getPosX(), spaceship->getPosY());
		graphics::drawText(50, 50, 40, info, br);
	}

	//design lifebar
	float player_life = spaceship ? spaceship->getRemainingLife() : 0.0f;
	br.outline_opacity = 0.0f;
	br.fill_color[0] = 1.0f;
	br.fill_color[1] = 0.2f;
	br.fill_color[2] = 0.2f;
	br.texture = "";
	br.fill_secondary_color[0] = 0.2f;
	br.fill_secondary_color[1] = 0.2f;
	br.fill_secondary_color[2] = 1.0f;
	br.gradient = true;
	br.gradient_dir_u = 1.0f;
	br.gradient_dir_v = 0.0f;
	graphics::drawRect(CANVAS_WIDTH - 100 - ((1.0f - player_life) * 120 / 2), 30, player_life * 120, 20, br);

	br.outline_opacity = 1.0f;
	br.gradient = false;
	br.fill_opacity = 0.0f;
	graphics::drawRect(CANVAS_WIDTH - 100 - ((1.0f - player_life) * 120 / 2), 30, player_life * 120, 20, br);
}

void Game::init()
{
	//graphics::setFont(std::string(ASSET_PATH) + "bitstream.ttf");
}

Game::Game()
{
}

Game::~Game()
{
	if (spaceship)
	{
		delete spaceship;
		delete laserbeam;
	}

}
