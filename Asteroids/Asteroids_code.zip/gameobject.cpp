#include "gameobject.h"

GameObject::GameObject(const Game& mygame)
	:game(mygame)
{
}
