#pragma once
#include "gameobject.h"
#include "config.h"
#include "scancodes.h"
#include "spaceship.h"

class Laser : public GameObject, public Collidable
{
private:
	float speed = 3.0f;
	//float pos_x = (CANVAS_WIDTH / 2) + 80, pos_y = (CANVAS_HEIGHT / 2) - 10;
	float pos_x = pos_x + 75;
	float pos_y = pos_y - 10;
	//float height = 1.0f;
	bool laser_active = true;
public:
	void update() override;
	void draw() override;
	void init()	override;
	Laser(const class Game& mygame);
	~Laser();
	bool isLaserActive() { return laser_active; }
	bool travelling;
	Disk getCollisionHull() const override;
};