#pragma once
#include <random>

float rand0to1();

struct Disk
{
	float cx, cy;
	float radius;
};
